require 'puppet/util/feature'

Puppet.features.add(:pe_puppet_authorization, :libs => ['hocon'])
