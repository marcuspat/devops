Updating MCO plugins
======

1. Ensure `update_mco_plugins.sh` still matches the plugins PE uses, and makes sense.
1. Run `bash update_mco_plugins.sh`
