require 'spec_helper'

describe 'puppet_enterprise' do
  it { should compile }
end
